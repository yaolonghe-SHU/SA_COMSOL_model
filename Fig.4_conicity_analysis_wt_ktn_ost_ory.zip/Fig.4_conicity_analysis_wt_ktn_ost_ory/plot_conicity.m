%% Data definition
% ost (3000)
a = [0, 0.1202, 0.2807, 0.3936, 0.4626, 0.5054, 0.5274, 0.5381, 0.5429, 0.5459, 0.5502, 0.5576, 0.5684, 0.5819, 0.5978, 0.6131, 0.6277, 0.6407, 0.6535, 0.6567, 0.6571, 0.6585, 0.6607, 0.6629, 0.6652, 0.6681, 0.6708, 0.6735, 0.6760, 0.6782, 0.6803, 0.6823, 0.6838, 0.6852, 0.6864, 0.6879, 0.6895, 0.6917, 0.6939, 0.6968, 0.7004, 0.7059, 0.7121, 0.7218, 0.7333];

% wt (4000)
b = [0, 0, 0, 0, 0.0028, 0.0122, 0.0196, 0.0259, 0.0324, 0.0395, 0.0487, 0.0603, 0.0747, 0.0936, 0.1150, 0.1376, 0.1625, 0.1861, 0.2074, 0.2313, 0.2522, 0.2750, 0.2945, 0.3137, 0.3321, 0.3382, 0.3462, 0.3549, 0.3639, 0.3729, 0.3819, 0.3908, 0.3995, 0.4080, 0.4173, 0.4254, 0.4334, 0.4413, 0.4492, 0.4574, 0.4662, 0.4761, 0.4876, 0.5023, 0.5220];

% ktn (5000)
d = [0, 0, 0, 0, 0.0026, 0.0119, 0.0191, 0.0249, 0.0308, 0.0373, 0.0443, 0.0543, 0.0665, 0.0807, 0.0977, 0.1155, 0.1346, 0.1526, 0.1725, 0.1904, 0.2080, 0.2250, 0.2414, 0.2431, 0.2460, 0.2505, 0.2550, 0.2601, 0.2651, 0.2698, 0.2741, 0.2783, 0.2819, 0.2844, 0.2863, 0.2880, 0.2894, 0.2907, 0.2924, 0.2945, 0.2978, 0.3031, 0.3115, 0.3264, 0.3487];

% new data (e)
e = [0, 0, 0, 0, 0.0020, 0.0107, 0.0169, 0.0216, 0.0248, 0.0271, 0.0285, 0.0291, 0.0289, 0.0278, 0.0256, 0.0223, 0.0179, 0.0118, 0.0047, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

% Merge into a matrix (45 rows x 4 columns)
c = [a; b; d; e]';  % Transpose so each column corresponds to one curve

%% Generate x-axis coordinates (cell height, unit: um)
x = 3 + (0:size(c,1)-1) * 0.25;

%% ====== User controls plotting parameters here ======
plot_interval = 2;  % 1 = all points, 2 = take every other point
% ===================================================

%% Select data based on the interval parameter
if plot_interval <= 1
    x_plot = x;
    c_plot = c;
    mode_str = 'All data points';
else
    indices = 1:plot_interval:length(x);
    x_plot = x(indices);
    c_plot = c(indices, :);
    mode_str = sprintf('Downsampled (step = %d)', plot_interval);
end

%% Plotting
figure('Position', [100, 100, 800, 600]);

% Distinguish curves by color and marker
plot(x_plot, c_plot(:,1), 'b-o', 'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', 'b'); hold on;
plot(x_plot, c_plot(:,2), 'r-s', 'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', 'r');
plot(x_plot, c_plot(:,3), 'k-^', 'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', 'k');
plot(x_plot, c_plot(:,4), 'm-d', 'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', 'm');  % New curve in magenta

xlabel('Cell height (\mum)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Taper value', 'FontSize', 12, 'FontWeight', 'bold');
title({'Taper vs. Cell Height for ost (3000), WT (4000), ktn (5000), and New Data (e)'; ['Mode: ' mode_str]}, ...
      'FontSize', 14, 'FontWeight', 'bold');

xlim([min(x)-0.1, max(x)+0.1]);
ylim([min(c(:))-0.05, max(c(:))+0.05]);

grid on;
set(gca, 'GridLineStyle', '--', 'GridAlpha', 0.6);

legend('ost (3000)', 'WT (4000)', 'ktn (5000)', 'oryzalin (e)', 'Location', 'best', 'FontSize', 11);




%% Downsampled data (plot_interval = 2)
% x-axis coordinates (um)
x = [3.00, 3.50, 4.00, 4.50, 5.00, 5.50, 6.00, 6.50, 7.00, 7.50, 8.00, 8.50, 9.00, 9.50, 10.00, 10.50, 11.00, 11.50, 12.00, 12.50, 13.00, 13.50, 14.00];

% a (3000)
a = [0, 0.2807, 0.4626, 0.5274, 0.5429, 0.5502, 0.5684, 0.5978, 0.6277, 0.6535, 0.6571, 0.6607, 0.6681, 0.6735, 0.6803, 0.6838, 0.6864, 0.6895, 0.6939, 0.7004, 0.7121, 0.7218, 0.7333];

% b (4000)
b = [0, 0, 0.0028, 0.0196, 0.0487, 0.0747, 0.1150, 0.1625, 0.2074, 0.2522, 0.2945, 0.3321, 0.3462, 0.3639, 0.3819, 0.3995, 0.4173, 0.4334, 0.4492, 0.4662, 0.4876, 0.5023, 0.5220];

% d (5000)
d = [0, 0, 0.0026, 0.0191, 0.0443, 0.0665, 0.0977, 0.1346, 0.1725, 0.2080, 0.2414, 0.2460, 0.2550, 0.2651, 0.2741, 0.2819, 0.2863, 0.2894, 0.2924, 0.2978, 0.3115, 0.3264, 0.3487];

% e (new data)
e = [0, 0, 0.0020, 0.0169, 0.0248, 0.0285, 0.0289, 0.0256, 0.0179, 0.0047, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];