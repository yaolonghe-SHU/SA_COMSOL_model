% Statistics based on grayscale values
clc; close all; clearvars;

% =====================================================================================
% Generate ColorBar_Value mapping data
% =====================================================================================
ColorBar_Value = zeros(256,2);
ColorBar_Value(:,1) = fliplr(linspace(0, 255, 256));    % fliplr reverses the vector
ColorBar_Value(:,2) = fliplr(linspace(4.64, 8.21, 256)); % fliplr reverses the vector


% =====================================================================================
% Compute the average value from grayscale images
% =====================================================================================
% Define the variable array
% variables = [1, 3, 4, 5, 6];
% variables = [1, 3, 5, 8, 11];
% Define the prefix string
prefix = 'Stage8-';
% variables = [1, 3, 5, 7, 12];
% variables = [1, 3, 5, 8, 12];
variables = [0, 1, 2, 3, 4];
% Loop through each element in the array
averageColorData = zeros(length(variables),1);
%%
iN = 5;
% for iN = 1:5 % length(variables)
    % Get the current element
    currentVariable = variables(iN);

    % Build the file name
    filename = sprintf('%s%d.png', prefix, currentVariable); % Use sprintf for string concatenation

    % Read the image
    % img = imread('stage8_6.png'); % Replace with your image file name
    img = imread(filename); % Read the image

    % Convert the image to grayscale
    grayImg = rgb2gray(img);

    % Compute the grayscale histogram
    [counts, ~] = imhist(grayImg);

    % Find the most frequent gray value (background color)
    [~, maxIndex] = max(counts);
    backgroundGray = maxIndex - 1; % Index starts at 1, gray value starts at 0

    % Set a threshold to remove the background
    threshold = backgroundGray;
    bwImg = grayImg > threshold + 20;

    % Set non-background pixels to their original color, and background to white
    noBackgroundImg = grayImg;
    noBackgroundImg(bwImg == 0) = 255;

    % Compute the average color of the non-background region
    colorIndices = noBackgroundImg(bwImg > 0);
    averageColor = mean(colorIndices(:), 1); % Convert value back to the 0-255 range

    % Display the average color result
    fprintf('%s%d: %f', prefix, currentVariable, averageColor);
    fprintf('\n'); % New line
    averageColorData(iN,1) = averageColor;

    % Display the processed image
    figure
    imshow(noBackgroundImg);
%     title('Image after background removal');
% end

% =================================================================================
% averageColor - HP mapping relationship
% =================================================================================
averageColor_HP = zeros(length(variables),2);
averageColor_HP(:,1) = averageColorData;
averageColor_HP(:,2) = interp1(ColorBar_Value(:,1), ColorBar_Value(:,2), averageColorData, 'linear');

    % Display the original image
    figure
    imshow(img);

% Generate ColorBar index
% % Read the image
% img2 = imread('ColorBar.png'); % Replace with your image file name
%
% % Convert the image to grayscale
% grayImg2 = rgb2gray(img2);
%
% % Display the processed image
% imshow(grayImg2);
% title('ColorBar');
%
% ColorBarData = zeros(length(grayImg2(:,1)),1);
% for jN = 1:length(ColorBarData(:,1))
%     ColorBarData(jN,1) = mean(grayImg2(jN,:));
% end

% ColorBar_Value = zeros(length(ColorBarData),2);
% ColorBar_Value(:,1) = ColorBarData;
% Valuemax = 0.8;     Valuemin = 0.0;
% ColorBar_Value(:,2) = fliplr(linspace(Valuemin, Valuemax, length(ColorBarData))); % fliplr reverses the vector
% save('ColorBar_Value.mat', 'ColorBar_Value');

% ColorBar_Value = zeros(256,2);
% ColorBar_Value(:,1) = fliplr(linspace(0, 255, 256)); % fliplr reverses the vector
% ColorBar_Value(:,2) = fliplr(linspace(0, 0.8, 256)); % fliplr reverses the vector
% save('ColorBar_Value.mat', 'ColorBar_Value');
% load('ColorBar_Value.mat');
(8.21-4.64)/255*averageColor+4.64