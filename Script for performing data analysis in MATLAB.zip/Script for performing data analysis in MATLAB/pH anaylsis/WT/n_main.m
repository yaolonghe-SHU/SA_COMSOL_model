% Statistics in grayscale - including pixel count (n) output
clc; close all; clearvars;

%=====================================================================================
% Generate ColorBar_Value mapping data
%=====================================================================================
ColorBar_Value = zeros(256,2);
ColorBar_Value(:,1) = fliplr(linspace(0, 255, 256));    % fliplr reverses the vector
ColorBar_Value(:,2) = fliplr(linspace(4.64, 8.21, 256)); % fliplr reverses the vector

%=====================================================================================
% Compute the average value from grayscale images
%=====================================================================================
% Define the variable array
prefix = 'Stage14-';
variables = [0, 2, 7, 10, 14];

% Initialize storage variables
averageColorData = zeros(length(variables), 1);
pixelCountData = zeros(length(variables), 1);  % Store pixel count (n) for each sample

%=====================================================================================
% Loop through each image
%=====================================================================================
fprintf('========== Processing Results ==========\n');
fprintf('Sample\t\tMean Gray\tPixel Count(n)\tpH\n');
fprintf('--------------------------------------------------------\n');

for iN = 1:length(variables)
    % Get the current element
    currentVariable = variables(iN);
    
    % Build the file name
    filename = sprintf('%s%d.png', prefix, currentVariable);
    
    % Read the image
    img = imread(filename);
    
    % Convert the image to grayscale
    grayImg = rgb2gray(img);
    
    % Compute the grayscale histogram
    [counts, ~] = imhist(grayImg);
    
    % Find the most frequent gray value (background color)
    [~, maxIndex] = max(counts);
    backgroundGray = maxIndex - 1; % Index starts at 1, gray value starts at 0
    
    % Set a threshold to remove the background
    threshold = backgroundGray;
    bwImg = grayImg > threshold + 20;
    
    % Extract foreground pixel values
    colorIndices = grayImg(bwImg > 0);
    
    % Compute pixel count (n)
    pixelCount = length(colorIndices);
    pixelCountData(iN) = pixelCount;
    
    % Compute the average color of the non-background region
    averageColor = mean(colorIndices(:), 1);
    averageColorData(iN) = averageColor;
    
    % Compute the corresponding pH value (using a linear formula)
    pH_value = (8.21 - 4.64) / 255 * averageColor + 4.64;
    
    % Display results
    fprintf('%s%d\t\t%.2f\t\t%d\t\t%.3f\n', ...
            prefix, currentVariable, averageColor, pixelCount, pH_value);
    
    % Display the processed image (background removed)
    noBackgroundImg = grayImg;
    noBackgroundImg(bwImg == 0) = 255;
    figure
    imshow(noBackgroundImg);
    title(sprintf('%s%d - Background Removed (n=%d)', prefix, currentVariable, pixelCount));
end

fprintf('--------------------------------------------------------\n');

%=====================================================================================
% Summary statistics
%=====================================================================================
% Compute the mean over all samples
avgPixelCount = mean(pixelCountData);
avgpH = mean((8.21 - 4.64) / 255 * averageColorData + 4.64);

fprintf('\n========== Summary Statistics ==========\n');
fprintf('Average pixel count (n): %.1f\n', avgPixelCount);
fprintf('Average pH: %.3f\n', avgpH);
fprintf('Total samples processed: %d\n', length(variables));

%=====================================================================================
% Display the original image before processing
%=====================================================================================
figure
imshow(img);
title(sprintf('%s%d - Original Image', prefix, currentVariable));

%=====================================================================================
% Optional: save results to file
%=====================================================================================
% Create results table
results = table(variables', averageColorData, pixelCountData, ...
                'VariableNames', {'SampleID', 'MeanGrayValue', 'PixelCount_n'});
% % Add pH column
% results.pH = (8.21 - 4.64) / 255 * results.MeanGrayValue + 4.64;

% Display table
disp('Results Table:');
disp(results);

% Save to Excel file (optional)
% writetable(results, 'pH_analysis_results.xlsx');
% fprintf('\nResults saved to pH_analysis_results.xlsx\n');

% Save to MAT file
save('pH_analysis_results.mat', 'results', 'variables', 'averageColorData', 'pixelCountData');
fprintf('Results saved to pH_analysis_results.mat\n');
