%% ============================================================
%  Quantification of degree of conicity
%  Y-axis ticks set to 0.15 intervals, clean border without top/right ticks
%  Each group contains 16 valid measurements (n = 16).
%  No outlier removal is applied in this script.
%  Statistics: Mann–Whitney U test (a.k.a. Wilcoxon rank-sum),
%              exact p-values, Bonferroni correction vs MOCK.
%  Plot: only one figure with text is displayed (no image export).
% ============================================================
clear; clc; close all;

%% ========== 1. Data used for statistics and plotting (n = 16 per group) ==========
MOCK     = [0.887733022168805; 0.873371573020106; 0.879452572620447; 0.883597221206060; ...
            0.961666620980517; 0.935617557448051; 0.902755356971498; 0.875197304706820; ...
            0.873872706125468; 0.925896664403902; 0.930271451459971; 0.900167322133691; ...
            0.872928931941719; 0.881292100543525; 0.956926786617109; 0.962977774544134];

ORYZALIN = [0.834280910178616; 0.846036664970764; 0.912013762394853; 0.859436829452720; ...
            0.821344664934459; 0.865869728565398; 0.812846607177624; 0.816515524908047; ...
            0.842105086194149; 0.861263982899612; 0.795763289729585; 0.786229746048299; ...
            0.815348451977315; 0.785124530707463; 0.838068000219155; 0.881511783747626];

FCC      = [0.937929018626320; 0.965996977693966; 0.935885416537001; 0.960024969184403; ...
            0.985971116653679; 0.913861909811278; 0.966245786620957; 0.971557749955440; ...
            0.941439162801089; 0.944664472441161; 1.02205144860248;  0.887414374379452; ...
            0.912783187388116; 0.898202192166109; 0.941635362349395; 0.979764046441425];

DCCD     = [0.754660949795620; 0.659212621627096; 0.662291118799186; 0.767580735424668; ...
            0.787220884022372; 0.626468139340186; 0.740783109200104; 0.726878201645816; ...
            0.832834871548480; 0.799643901744767; 0.826978140720522; 0.893218304978293; ...
            0.820240433272623; 0.796865680809147; 0.839634295455835; 0.756163359807663];

DCCD_ORY = [0.813217883943939; 0.793306925140855; 0.657104947868813; 0.619247847448900; ...
            0.667822941265664; 0.546028532091158; 0.744951514945275; 0.761881130799022; ...
            0.690525241199138; 0.832003996811104; 0.737086171405279; 0.637159862455183; ...
            0.641654403054513; 0.633438804155176; 0.728354119266199; 0.622651433884667];

FCC_ORY  = [0.752520765384479; 0.787960669499580; 0.709163073729394; 0.887217636294239; ...
            0.734555761768961; 0.775569291919929; 0.828686735435804; 0.746788583106950; ...
            0.875257038975058; 0.835909491462242; 0.850340697221857; 0.768933430888984; ...
            0.764432694709870; 0.721859844903864; 0.707624825067733; 0.646497889901739];

trimmed = { MOCK, ORYZALIN, FCC, DCCD, DCCD_ORY, FCC_ORY };
names   = {'MOCK', 'ORYZALIN', 'FCC', 'DCCD', 'DCCD+ORY', 'FCC+ORY'};
nGroups = numel(trimmed);

fprintf('\nSample sizes (valid measurements):\n');
for i = 1:nGroups
    fprintf('  %-10s : n = %d\n', names{i}, numel(trimmed{i}));
end

%% ========== 2. Export plot data (.dat / CSV) ==========
all_plot_data = [];
all_plot_groups = {};
for i = 1:nGroups
    all_plot_data = [all_plot_data; trimmed{i}];
    all_plot_groups = [all_plot_groups; repmat(names(i), numel(trimmed{i}), 1)];
end

% Long-format .dat
dat_long = 'Conicity_Analysis_Long.dat';
fid = fopen(dat_long, 'w');
if fid == -1, error('Cannot create file: %s', dat_long); end
fprintf(fid, 'Group\tDegree_of_conicity\n');
for i = 1:nGroups
    for v = trimmed{i}(:)'
        fprintf(fid, '%s\t%.15f\n', names{i}, v);
    end
end
fclose(fid);
fprintf('\nAnalysis data saved: %s\n', dat_long);

% Long-format CSV
T_plot = table(all_plot_groups, all_plot_data, ...
    'VariableNames', {'Group', 'Degree_of_conicity'});
csv_fname = 'Conicity_Analysis_Long.csv';
writetable(T_plot, csv_fname);
fprintf('Analysis data saved: %s\n', csv_fname);

%% ========== 3. Statistical test: Mann–Whitney U (Wilcoxon rank-sum) ==========
k      = nGroups - 1;
alphaK = 0.05 / k;
pRaw   = nan(1, k);
Ustat  = nan(1, k);
n1     = numel(trimmed{1});

for j = 1:k
    [pRaw(j), ~, stats] = ranksum(trimmed{1}, trimmed{j+1}, 'method', 'exact');
    W = stats.ranksum;
    Ustat(j) = W - n1*(n1+1)/2;
end

fprintf('\nMann–Whitney U tests vs MOCK (exact p; Bonferroni alpha = %.4f):\n', alphaK);
fprintf('  %-12s %10s %14s\n', 'Group', 'U', 'p');
for j = 1:k
    fprintf('  %-12s %10.1f %14.6g\n', names{j+1}, Ustat(j), pRaw(j));
end

colors = [
    0.53 0.76 0.35;  % MOCK: green
    0.93 0.28 0.28;  % ORYZALIN: red
    0.83 0.58 0.40;  % FCC: brown
    0.43 0.69 0.86;  % DCCD: blue
    0.60 0.44 0.71;  % DCCD+ORY: purple
    0.95 0.67 0.25   % FCC+ORY: orange
];

%% ========== 4. Plot (single figure, with text, no export) ==========
plot_conicity(trimmed, names, colors, pRaw, alphaK);

disp('Figure displayed successfully. (Y-axis tick interval = 0.15)');

%% ========== 5. Plotting function ==========
function plot_conicity(trimmed, names, colors, pRaw, alphaK)
    fig_w_inch = 1100 / 96;
    fig_h_inch = 750 / 96;

    figure('Color','w', 'Units', 'inches', 'Position', [1 1 fig_w_inch fig_h_inch]);
    hold on;

    nGroups = numel(trimmed);
    k = nGroups - 1;

    % --- Box plot ---
    for i = 1:nGroups
        y = trimmed{i};
        q = quantile(y, [0.25 0.5 0.75]);
        iqr_val = q(3) - q(1);
        w_lo = min(y(y >= q(1) - 1.5*iqr_val));
        w_hi = max(y(y <= q(3) + 1.5*iqr_val));
        box_w = 0.5; c = colors(i,:);

        rectangle('Position', [i-box_w/2, q(1), box_w, iqr_val], 'EdgeColor', c, 'LineWidth', 1.8);
        plot([i-box_w/2, i+box_w/2], [q(2), q(2)], 'k-', 'LineWidth', 2.0);
        plot([i, i], [q(3), w_hi], '--', 'Color', c, 'LineWidth', 1.5);
        plot([i, i], [q(1), w_lo], '--', 'Color', c, 'LineWidth', 1.5);
        plot([i-0.1, i+0.1], [w_hi, w_hi], '-', 'Color', c, 'LineWidth', 1.5);
        plot([i-0.1, i+0.1], [w_lo, w_lo], '-', 'Color', c, 'LineWidth', 1.5);
    end

    % --- Scatter (jittered) ---
    rng(7); jw = 0.1;
    for i = 1:nGroups
        ni = numel(trimmed{i});
        x = i + (rand(1,ni)-0.5)*2*jw;
        scatter(x, trimmed{i}, 42, colors(i,:), 'filled', ...
            'MarkerEdgeColor', 'k', 'LineWidth', 0.75, 'MarkerFaceAlpha', 0.75);
    end

    % --- Significance brackets and asterisks ---
    y_max = max(vertcat(trimmed{:}));
    current_y = max(y_max + 0.05, 1.02);
    yr = 0.05;
    top_line_y = current_y;

    for j = 1:k
        if pRaw(j) < alphaK
            if pRaw(j) < alphaK/10, stars = '***';
            elseif pRaw(j) < alphaK/2, stars = '**';
            else, stars = '*';
            end

            x1 = 1; x2 = j + 1; drop = 0.015;
            plot([x1 x1 x2 x2], [current_y-drop, current_y, current_y, current_y-drop], 'k-', 'LineWidth', 1.5);

            text((x1+x2)/2, current_y + 0.005, stars, ...
                'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
                'FontSize', 16, 'FontWeight', 'bold', 'FontName', 'Arial');

            top_line_y = current_y + 0.03;
            current_y = current_y + yr;
        end
    end

    % --- Axes settings ---
    set(gca, 'FontSize', 14, 'FontName', 'Arial', ...
             'TickDir', 'in', ...
             'LineWidth', 2.0, ...
             'TickLength', [0.015 0.03], ...
             'XColor', 'k', 'YColor', 'k');

    xlim([0.2, nGroups+0.8]);
    y_limit = max(1.15, top_line_y + 0.05);
    ylim([0.4, y_limit]);

    y_ticks = 0.4:0.15:y_limit;
    y_ticks = round(y_ticks * 100) / 100;
    set(gca, 'YTick', y_ticks);

    set(gca, 'XTick', 1:nGroups, 'XTickLabel', names, 'XTickLabelRotation', 45);
    ylabel('Degree of conicity', 'FontSize', 16, 'FontWeight', 'bold', 'FontName', 'Arial');

    box off;
    ax = gca;
    x_l = get(ax, 'XLim');
    y_l = get(ax, 'YLim');
    plot(x_l, [y_l(2) y_l(2)], 'k-', 'LineWidth', 2.0);
    plot([x_l(2) x_l(2)], y_l, 'k-', 'LineWidth', 2.0);

    hold off;
end