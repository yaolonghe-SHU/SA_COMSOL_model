clear; clc; close all

%% 1. Raw data (independent samples, 8 rows x 21 columns)
D = [
0.70763	0.71061	0.8438	0.48676	0.63998	0.91814	0.84683	0.84786	0.78728	0.82749	0.5922	0.80209	0.87668	0.74645	0.89225	0.81519	0.81402	0.85124	0.92905	0.77124	0.9078
0.61989	0.84689	0.75768	0.64365	0.68665	0.73225	0.86473	0.82637	0.86812	0.83131	0.88976	0.81043	0.80284	0.73692	0.77675	0.8663	0.84313	0.94313	0.83425	0.71434	0.81161
0.69988	0.78756	0.95367	0.56638	0.65609	0.80424	0.73492	0.67426	0.67651	0.76534	0.80399	0.70462	0.74751	0.78038	0.7935	0.933	0.78169	0.79	0.90584	0.80541	0.93202
0.70048	0.66648	0.81408	0.49629	0.85286	0.84615	0.71646	0.63786	0.77776	0.77208	0.66292	0.72413	0.86314	0.64747	0.78777	0.87683	0.86346	0.84869	0.78716	0.71296	0.9412
0.76244	0.58819	0.77652	0.5297	0.71739	0.79145	0.81454	0.76563	0.79984	0.83489	0.63236	0.74913	0.85634	0.81175	0.73854	0.84912	0.80276	0.79603	0.8271	0.67637	0.86225
0.7381	0.78495	0.82742	0.61039	0.86438	0.55752	0.76872	0.64623	0.74922	0.77655	0.75386	0.77607	0.74735	0.5932	0.85475	0.88529	0.79865	0.78833	0.75645	0.7191	0.85414
0.74437	0.71209	0.85654	0.50334	0.80695	0.5067	0.79269	0.85839	0.78501	0.77554	0.77175	0.87052	0.84804	0.76029	0.863	0.85966	0.79867	0.804	0.76623	0.74705	0.88658
0.7003	0.70065	0.90757	0.71536	0.78958	0.7441	0.8103	0.69228	0.79362	0.89515	0.84796	0.75481	0.90247	0.68325	0.82433	0.87158	0.89277	0.7828	0.78569	0.72109	0.86016
];

%% 2. Grouping
WT  = D(:,1:3:end);
ktn = D(:,2:3:end);
ost = D(:,3:3:end);
stages = 8:14;
groupNames = {'WT', 'ktn', 'ost'};
nGroups = 3;
nPerGroup = size(D,1);

% ============================================================

% ============================================================
Stage_list = [];
Group_list = {};
Value_list = [];

for i = 1:length(stages)

    Stage_list = [Stage_list; repmat(stages(i), nGroups*nPerGroup, 1)];
    Group_list = [Group_list; repmat({'WT'}, nPerGroup, 1); repmat({'ktn'}, nPerGroup, 1); repmat({'ost'}, nPerGroup, 1)];
    Value_list = [Value_list; WT(:,i); ktn(:,i); ost(:,i)];
end

T_raw = table(Stage_list, Group_list, Value_list, 'VariableNames', {'Stage', 'Group', 'Conicity'});
writetable(T_raw, 'Conicity_RawData_Long.csv');
fprintf('已保存原始数据: Conicity_RawData_Long.csv\n');
% ============================================================


%% 3. Descriptive statistics (output)
fprintf('\n========== DESCRIPTIVE STATISTICS (Mean ± SD, n = %d) ==========\n', nPerGroup);
fprintf('Stage\tWT_mean±SD\t\tktn_mean±SD\t\tost_mean±SD\n');
for i = 1:length(stages)
    m1 = mean(WT(:,i)); s1 = std(WT(:,i));
    m2 = mean(ktn(:,i)); s2 = std(ktn(:,i));
    m3 = mean(ost(:,i)); s3 = std(ost(:,i));
    fprintf('%2d\t%.3f±%.3f\t\t%.3f±%.3f\t\t%.3f±%.3f\n', ...
        stages(i), m1, s1, m2, s2, m3, s3);
end

%% 4. Kruskal-Wallis + Dunn post-hoc test
fprintf('\n========== KRUSKAL-WALLIS TEST & DUNN POST-HOC (α = 0.05) ==========\n');
alpha = 0.05;
n_comparisons = 3;
adj_alpha = alpha / n_comparisons;
dunn_padj = cell(length(stages), 3);

for i = 1:length(stages)
    data_WT  = WT(:,i);
    data_ktn = ktn(:,i);
    data_ost = ost(:,i);
    all_data = [data_WT; data_ktn; data_ost];
    groups = [ones(nPerGroup,1); 2*ones(nPerGroup,1); 3*ones(nPerGroup,1)];
    
    [p_kw, tbl, ~] = kruskalwallis(all_data, groups, 'off');
    H = tbl{2,5}; df = tbl{2,3};
    fprintf('\nStage %d: χ² = %.2f, df = %d, p = %.4f\n', stages(i), H, df, p_kw);
    
    [ranks, tie_adj] = tiedrank(all_data);
    N = length(all_data);
    total_rank_var = (N*(N+1)/12 - tie_adj);
    mean_ranks = [mean(ranks(groups==1)), mean(ranks(groups==2)), mean(ranks(groups==3))];
    n_g = [nPerGroup, nPerGroup, nPerGroup];
    
    pairs = [1,2; 1,3; 2,3];
    pair_names = {'WT vs ktn', 'WT vs ost', 'ktn vs ost'};
    for j = 1:3
        a = pairs(j,1); b = pairs(j,2);
        z = abs(mean_ranks(a) - mean_ranks(b)) / sqrt(total_rank_var * (1/n_g(a) + 1/n_g(b)));
        p_raw = 2 * (1 - normcdf(z));
        p_adj = min(p_raw * n_comparisons, 1);
        dunn_padj{i,j} = p_adj;
        fprintf('    %s: z = %.2f, p_adj = %.4f %s\n', pair_names{j}, z, p_adj, ternary(p_adj < adj_alpha, '*', ''));
    end
end

%% 5. Effect sizes
fprintf('\n========== EFFECT SIZES ==========\n');
fprintf('Stage\tEpsilon²\tInterpretation\n');
for i = 1:length(stages)
    data_WT=WT(:,i); data_ktn=ktn(:,i); data_ost=ost(:,i);
    all_data=[data_WT;data_ktn;data_ost]; groups=[ones(nPerGroup,1);2*ones(nPerGroup,1);3*ones(nPerGroup,1)];
    [~,tbl]=kruskalwallis(all_data,groups,'off');
    H=tbl{2,5}; N=length(all_data); eps2=H/(N-1);
    if eps2<0.01, interp='negligible'; elseif eps2<0.06, interp='small'; elseif eps2<0.14, interp='medium'; else interp='large'; end
    fprintf('%d\t%.3f\t\t%s\n',stages(i),eps2,interp);
end
fprintf('\n--- Pairwise Cliff''s Delta ---\n');
for i=1:length(stages)
    data_WT=WT(:,i); data_ktn=ktn(:,i); data_ost=ost(:,i);
    pairs={data_WT,data_ktn,'WT vs ktn'; data_WT,data_ost,'WT vs ost'; data_ktn,data_ost,'ktn vs ost'};
    for j=1:3
        x=pairs{j,1}; y=pairs{j,2}; name=pairs{j,3};
        n1=length(x); n2=length(y); dom=0;
        for ii=1:n1, for jj=1:n2
                if x(ii)>y(jj), dom=dom+1; elseif x(ii)<y(jj), dom=dom-1; end
            end
        end
        cliff=dom/(n1*n2);
        if abs(cliff)<0.147, interp='negligible'; elseif abs(cliff)<0.33, interp='small'; elseif abs(cliff)<0.474, interp='medium'; else interp='large'; end
        fprintf('Stage %d %s: δ=%.3f (%s)\n',stages(i),name,cliff,interp);
    end
end

%% 6. Compact letter display (store and output)
fprintf('\n========== COMPACT LETTER DISPLAY ==========\n');
cld_matrix = cell(length(stages),3);
for i = 1:length(stages)
    means = [mean(WT(:,i)), mean(ktn(:,i)), mean(ost(:,i))];
    [~, idx] = sort(means, 'descend');
    letters = {'a','b','c'};
    p_adj_mat = inf(3);
    p_adj_mat(1,2) = dunn_padj{i,1}; p_adj_mat(2,1) = dunn_padj{i,1};
    p_adj_mat(1,3) = dunn_padj{i,2}; p_adj_mat(3,1) = dunn_padj{i,2};
    p_adj_mat(2,3) = dunn_padj{i,3}; p_adj_mat(3,2) = dunn_padj{i,3};
    final_letters = cell(1,3);
    for g = 1:3, final_letters{idx(g)} = letters{g}; end
    for g = 1:2
        a = idx(g); b = idx(g+1);
        if p_adj_mat(a,b) >= 0.05, final_letters{b} = final_letters{a}; end
    end
    for g = 1:3, cld_matrix{i,g} = final_letters{g}; end
    fprintf('Stage %d: ', stages(i));
    for g = 1:3, fprintf('%s=%s ', groupNames{g}, final_letters{g}); end
    fprintf('\n');
end

%% ========== 7. Colored boxplot + alternating background colors ==========
% Colors
color_WT  = [0.30 0.60 0.90];
color_ktn = [0.20 0.75 0.55];
color_ost = [0.95 0.65 0.25];
face_alpha = 0.35;
box_width = 0.28;

% Two background colors (soft light gray and very light blue/beige)
bg_color1 = [0.97 0.97 0.97];   % light gray
bg_color2 = [0.94 0.97 1.00];   % very light blue
% bg_color2 = [1.00 0.97 0.94];  % light beige (alternative)

fig = figure('Units', 'centimeters', 'Position', [2, 2, 14, 8], 'Color', 'w');
hold on;

% --- 1. Alternating background boxes ---
for s = 1:length(stages)
    % Choose background color: odd stages use bg_color1, even stages use bg_color2
    if mod(s,2) == 1
        bg_color = bg_color1;
    else
        bg_color = bg_color2;
    end
    
    x_left   = (s-1)*3 + 0.5;   % covers the three boxes
    x_right  = (s-1)*3 + 3.5;
    y_bottom = 0.1;
    y_top    = 1.25;
    rectangle('Position', [x_left, y_bottom, x_right-x_left, y_top-y_bottom], ...
        'FaceColor', bg_color, 'EdgeColor', 'none', 'Curvature', 0.1);
    % Stage label (above the background box)
    text(mean([x_left, x_right]), y_top - 0.03, sprintf('Stage %d', stages(s)), ...
        'HorizontalAlignment', 'center', 'FontSize', 9, 'FontWeight', 'bold', ...
        'BackgroundColor', 'w', 'EdgeColor', 'none');
end

% --- 2. Boxes ---
for s = 1:length(stages)
    for g = 1:3
        if g == 1, data = WT(:,s); col = color_WT;
        elseif g == 2, data = ktn(:,s); col = color_ktn;
        else data = ost(:,s); col = color_ost; end
        
        q = quantile(data, [0.25 0.5 0.75]);
        iqr = q(3) - q(1);
        lower_whisker = max(min(data), q(1) - 1.5*iqr);
        upper_whisker = min(max(data), q(3) + 1.5*iqr);
        x_center = (s-1)*3 + g;
        x_left   = x_center - box_width/2;
        x_right  = x_center + box_width/2;
        
        patch([x_left, x_right, x_right, x_left], [q(1), q(1), q(3), q(3)], col, ...
            'EdgeColor', 'k', 'LineWidth', 1.0, 'FaceAlpha', face_alpha);
        plot([x_left, x_right], [q(2), q(2)], 'k-', 'LineWidth', 1.8);
        plot([x_center, x_center], [lower_whisker, q(1)], 'k-', 'LineWidth', 1.0);
        plot([x_center, x_center], [q(3), upper_whisker], 'k-', 'LineWidth', 1.0);
        plot([x_center-0.1, x_center+0.1], [lower_whisker, lower_whisker], 'k-', 'LineWidth', 1.0);
        plot([x_center-0.1, x_center+0.1], [upper_whisker, upper_whisker], 'k-', 'LineWidth', 1.0);
    end
end

% --- 3. Scatter points (same color, smaller) ---
for s = 1:length(stages)
    for g = 1:3
        if g==1, data = WT(:,s); col = color_WT;
        elseif g==2, data = ktn(:,s); col = color_ktn;
        else data = ost(:,s); col = color_ost; end
        x = (s-1)*3 + g;
        jitter = (rand(size(data)) - 0.5) * 0.18;
        scatter(x + jitter, data, 14, col, 'filled', ...
            'MarkerFaceAlpha', 0.7, 'MarkerEdgeColor', 'k', 'LineWidth', 0.5);
    end
end

% --- 4. Compact letter display ---
y_offset_letter = 0.025;
for s = 1:length(stages)
    for g = 1:3
        if g==1, data = WT(:,s);
        elseif g==2, data = ktn(:,s);
        else data = ost(:,s); end
        max_val = max(data);
        xc = (s-1)*3 + g;
        letter = cld_matrix{s, g};
        text(xc, max_val + y_offset_letter, letter, ...
            'HorizontalAlignment','center', 'FontSize',11, 'FontWeight','bold', ...
            'Color','k', 'BackgroundColor','none');
    end
end

% --- 5. Optional: traditional significance asterisk lines (kept) ---
max_vals = zeros(length(stages), 3);
for s = 1:length(stages)
    for g = 1:3
        if g==1, data = WT(:,s);
        elseif g==2, data = ktn(:,s);
        else data = ost(:,s); end
        max_vals(s,g) = max(data);
    end
end
base_y_offset = 0.03;
y_offset_step = 0.045;
for s = 1:length(stages)
    p_vals = [dunn_padj{s,1}, dunn_padj{s,2}, dunn_padj{s,3}];
    sig_pairs = [];
    if p_vals(1) < 0.05, sig_pairs = [sig_pairs; 1,2]; end
    if p_vals(2) < 0.05, sig_pairs = [sig_pairs; 1,3]; end
    if p_vals(3) < 0.05, sig_pairs = [sig_pairs; 2,3]; end
    if isempty(sig_pairs), continue; end
    x_centers = (s-1)*3 + (1:3);
    group_max = max_vals(s,:);
    pair_max = zeros(size(sig_pairs,1),1);
    for k = 1:size(sig_pairs,1)
        g1 = sig_pairs(k,1); g2 = sig_pairs(k,2);
        pair_max(k) = max(group_max(g1), group_max(g2));
    end
    [~, idx_sort] = sort(pair_max);
    sig_pairs = sig_pairs(idx_sort, :);
    pair_max = pair_max(idx_sort);
    for k = 1:size(sig_pairs,1)
        g1 = sig_pairs(k,1); g2 = sig_pairs(k,2);
        x1 = x_centers(g1); x2 = x_centers(g2);
        y_top = pair_max(k) + base_y_offset + (k-1)*y_offset_step;
        plot([x1, x2], [y_top, y_top], 'k-', 'LineWidth', 1.0);
        if (g1==1 && g2==2), p_val = p_vals(1);
        elseif (g1==1 && g2==3), p_val = p_vals(2);
        else p_val = p_vals(3); end
        if p_val < 0.001, sig_text = '***';
        elseif p_val < 0.01, sig_text = '**';
        else sig_text = '*'; end
        text(mean([x1,x2]), y_top + 0.004, sig_text, ...
            'HorizontalAlignment', 'center', 'FontSize', 9, 'FontName', 'Helvetica');
    end
end

% --- 6. Axes ---
set(gca, 'Box', 'off', 'TickDir', 'out', 'TickLength', [0.02 0.025]);
set(gca, 'XTick', 1.5:3:21, 'XTickLabel', stages, 'FontSize', 10, 'FontName', 'Helvetica');
set(gca, 'YTick', 0.2:0.2:1.0, 'FontSize', 10, 'FontName', 'Helvetica');
xlabel('Stage', 'FontSize', 11, 'FontName', 'Helvetica', 'FontWeight', 'normal');
ylabel('Degree of conicity', 'FontSize', 11, 'FontName', 'Helvetica', 'FontWeight', 'normal');
xlim([0.5, length(stages)*3+0.5]);
ylim([0.1, 1.3]);

grid on;
set(gca, 'XGrid', 'off', 'YGrid', 'on', 'GridLineStyle', ':', 'GridColor', [0.8 0.8 0.8], 'GridAlpha', 0.6);

% Legend
h1 = plot(NaN, NaN, 's', 'MarkerSize', 8, 'MarkerFaceColor', color_WT, ...
    'MarkerEdgeColor', 'k', 'LineWidth', 0.8, 'DisplayName', 'WT');
h2 = plot(NaN, NaN, 's', 'MarkerSize', 8, 'MarkerFaceColor', color_ktn, ...
    'MarkerEdgeColor', 'k', 'LineWidth', 0.8, 'DisplayName', 'ktn');
h3 = plot(NaN, NaN, 's', 'MarkerSize', 8, 'MarkerFaceColor', color_ost, ...
    'MarkerEdgeColor', 'k', 'LineWidth', 0.8, 'DisplayName', 'ost');
legend([h1, h2, h3], {'WT', 'ktn', 'ost'}, 'Location', 'northwest', ...
    'Box', 'off', 'FontSize', 9, 'FontName', 'Helvetica');

hold off;

%% Helper function
function s = ternary(cond, tval, fval)
    if cond, s = tval; else, s = fval; end
end