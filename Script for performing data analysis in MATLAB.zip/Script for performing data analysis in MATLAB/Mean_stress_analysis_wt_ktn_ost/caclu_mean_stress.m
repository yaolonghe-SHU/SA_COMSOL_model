clear; clc; close all;

% 1. Load data
%load('4000s_ktn-afa_sp-zData');   % Make sure the file extension is correct
%load('4000s_ost-afa_sp-zData');   % Make sure the file extension is correct
load('4000s_wild_polarity-afa_sp-zData');   % Make sure the file extension is correct
rz = rzData;                     
[num_pts, num_cols] = size(rz);
fprintf('Data size: %d rows x %d columns\n', num_pts, num_cols);

% 2. Extract even columns and calculate the mean
even_cols = 2:2:num_cols;
num_even = length(even_cols);
store = zeros(1, num_even);

for i = 1:num_even
    col_idx = even_cols(i);
    stress_data = rz(:, col_idx);
    store(i) = mean(stress_data, 'omitnan');
end

% 3. Plot: x-axis is height (3–14 μm)
x_height = linspace(3, 14, num_even);   % or linearly map even_cols

plot(x_height, store, 'o-', 'LineWidth', 2);
xlabel('Height (μm)');
ylabel('Mean stress');
title('Mean stress at each height');
grid on;
