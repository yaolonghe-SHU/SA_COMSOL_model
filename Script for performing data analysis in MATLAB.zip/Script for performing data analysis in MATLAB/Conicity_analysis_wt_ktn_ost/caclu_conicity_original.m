clear; clc; close all;

% ============================================================
% Load data
% ============================================================

% 
%load('ost_4000s_rzData');
% 
% 
%load('ktn_4000s_rzData');

load('wt4000s_rzData');


rz = rzData;
[num_pts, num_cols] = size(rz);
num_curves = num_cols / 2;

fprintf('Found %d curves in total, starting preprocessing...\n', num_curves);

% Physical x-coordinate (starts at 3 um, step size 0.25 um)
x_physical = 3 + (0:num_curves-1) * 0.25;

% Preallocate storage for all taper values
all_taper = NaN(1, num_curves);

% ============================================================
% Taper calculation function (encapsulated separately, defined at end of file)
% ============================================================
% (Function definition is at the end of the file)

% ============================================================
% Process each curve one by one
% ============================================================
for idx = 1:num_curves
    % Extract the radius and height of the idx-th curve
    r = rz(:, 2*idx-1);
    h = rz(:, 2*idx);
    
    % Remove invalid data
    valid = ~isnan(r) & ~isnan(h) & (r > 0) & (h > 0);
    r = r(valid);
    h = h(valid);
    
    if length(r) < 5
        fprintf('Curve %d: not enough valid points, skipping\n', idx);
        continue;
    end
    
    % Sort by height (ensure h is monotonically increasing)
    [h_sorted, sort_idx] = sort(h);
    r_sorted = r(sort_idx);
    
    % ---- Call the taper calculation function ----
    taper = compute_taper(r_sorted, h_sorted, false);  % false = do not plot separately
    
    if ~isnan(taper)
        all_taper(idx) = taper;
    else
        fprintf('Curve %d: taper calculation abnormal, skipping\n', idx);
    end
end

% ============================================================
% Display results
% ============================================================

% Filter valid results
valid_idx = find(~isnan(all_taper));
valid_physical = x_physical(valid_idx);
valid_taper = all_taper(valid_idx);

fprintf('\n========== Processing complete ==========\n');
fprintf('Total number of curves: %d\n', num_curves);
fprintf('Number of valid curves: %d\n', length(valid_idx));
fprintf('Taper range: %.4f ~ %.4f\n', min(valid_taper), max(valid_taper));
fprintf('Mean taper: %.4f +/- %.4f\n', mean(valid_taper), std(valid_taper));

% ============================================================
% Plotting
% ============================================================

% ---- Figure 1: Taper as a function of height ----
figure('Position', [100, 100, 1000, 400]);

subplot(1, 2, 1);
plot(valid_physical, valid_taper, 'bo-', 'LineWidth', 2, 'MarkerSize', 6);
xlabel('Cell height (\mum)');
ylabel('Taper value');
title('Taper vs. Cell Height');
grid on;

% ---- Figure 2: Histogram of taper distribution ----
subplot(1, 2, 2);
histogram(valid_taper, 10, 'FaceColor', [0.3 0.6 0.9]);
xlabel('Taper value');
ylabel('Frequency');
title(sprintf('Taper Distribution (n=%d)', length(valid_taper)));
grid on;

% ---- Figure 3: Taper values of all valid curves (by index) ----
figure('Position', [100, 100, 800, 400]);
bar(valid_idx, valid_taper, 'FaceColor', [0.3 0.6 0.9]);
xlabel('Curve index');
ylabel('Taper value');
title('Taper Value of Each Curve');
grid on;

% ---- Figure 4: Detailed geometric analysis of a middle curve ----
% Select a middle curve among the valid curves for detailed display
% mid_idx = valid_idx(round(end/2));


mid_idx = 2;





fprintf('\nShowing detailed analysis of curve %d...\n', mid_idx);

% Re-extract the data of this curve
r = rz(:, 2*mid_idx-1);
h = rz(:, 2*mid_idx);
valid = ~isnan(r) & ~isnan(h) & (r > 0) & (h > 0);
r = r(valid);
h = h(valid);
[h_sorted, sort_idx] = sort(h);
r_sorted = r(sort_idx);

% Call the plotting mode
compute_taper(r_sorted, h_sorted, true);
valid_taper
fprintf('\nAll done!\n');

% ============================================================
% Taper calculation function (must be placed at the end of the file)
% ============================================================
function taper = compute_taper(r, h, do_plot)
    % Inputs:
    %   r      : radius vector (from base to tip)
    %   h      : height vector (from base to tip)
    %   do_plot: true = plot, false = do not plot
    % Output:
    %   taper  : taper value
    
    % ---- Step 1: Smoothing ----
    if length(r) >= 5
        r_smooth = smooth(r, 5);
    else
        r_smooth = r;
    end
    
    % Ensure data is ordered from base to tip (h increasing)
    if h(1) > h(end)
        h = flipud(h);
        r_smooth = flipud(r_smooth);
    end
    
    % ---- Step 2: Determine tip and base ----
    [~, idx_peak] = max(h);
    r_peak = r_smooth(idx_peak);
    h_peak = h(idx_peak);
    
    [~, idx_base] = min(h);
    r_base = r_smooth(idx_base);
    h_base = h(idx_base);
    
    % ---- Step 3: Cell volume (solid of revolution) ----
    V_cell = pi * trapz(h, r_smooth.^2);
    
    % ---- Step 4: Inscribed cone volume ----
    cone_h = h_peak - h_base;
    V_cone = (1/3) * pi * r_base^2 * cone_h;
    
    % ---- Step 5: Circumscribed sphere (center on the Y-axis) ----
    c = (r_base^2 + h_base^2 - h_peak^2) / (2 * (h_base - h_peak));
    R = abs(h_peak - c);
    
    if ~isfinite(R) || R > 20*max(r_smooth) || R < 0.1
        taper = NaN;
        return;
    end
    
    % ---- Step 6: Spherical cap volume ----
    h_cap = h_peak - h_base;
    V_sphere_cap = pi * h_cap^2 * (R - h_cap/3);
    
    % ---- Step 7: Taper ----
    if abs(V_sphere_cap - V_cone) < 1e-12
        taper = NaN;
    else
        taper = (V_sphere_cap - V_cell) / (V_sphere_cap - V_cone);
    end
    
    % Clamp taper to a reasonable range [0, 1]
    if taper < 0
        taper = 0;
    elseif taper > 1
        taper = 1;
    end
    
    % ---- Step 8: Visualization (optional) ----
    if do_plot
        figure('Position', [100, 100, 1000, 500]);
        
        % Left panel: contour and geometric elements
        subplot(1, 2, 1);
        hold on;
        
        plot(r_smooth, h, 'b-', 'LineWidth', 2.5);
        plot(-r_smooth, h, 'b-', 'LineWidth', 2.5);
        
        plot([0, r_base, 0], [h_peak, h_base, h_peak], 'g--', 'LineWidth', 2);
        plot([0, -r_base, 0], [h_peak, h_base, h_peak], 'g--', 'LineWidth', 2);
        
        theta_base = atan2(h_base - c, r_base);
        theta_start = theta_base;
        theta_end = pi - theta_base;
        if theta_start > theta_end
            temp = theta_start; theta_start = theta_end; theta_end = temp;
        end
        theta_arc = linspace(theta_start, theta_end, 100);
        r_arc = R * cos(theta_arc);
        h_arc = c + R * sin(theta_arc);
        plot(r_arc, h_arc, 'r--', 'LineWidth', 2);
        plot(-r_arc, h_arc, 'r--', 'LineWidth', 2);
        
        plot(0, h_peak, 'k*', 'MarkerSize', 12, 'LineWidth', 2);
        plot(r_base, h_base, 'ms', 'MarkerSize', 10, 'LineWidth', 2);
        plot(-r_base, h_base, 'ms', 'MarkerSize', 10, 'LineWidth', 2);
        plot(0, c, 'ro', 'MarkerSize', 10, 'LineWidth', 2);
        plot([-r_base, r_base], [h_base, h_base], 'Color', [0.5 0.5 0.5], 'LineStyle', '--', 'LineWidth', 1.5);
        
        text(0, h_peak + 0.5, 'Tip', 'FontSize', 10, 'Color', 'k', 'HorizontalAlignment', 'center');
        text(r_base + 0.3, h_base, 'Base', 'FontSize', 10, 'Color', 'm');
        text(0.2, c + 0.3, 'Sphere center', 'FontSize', 10, 'Color', 'r');
        text(r_base*0.4, (h_peak+h_base)/2, 'Inscribed cone', 'FontSize', 9, 'Color', [0 0.6 0]);
        text(R*0.3, c + 1.5, sprintf('R=%.2f', R), 'FontSize', 9, 'Color', 'r');
        
        axis equal;
        xlim([-max(r_smooth)*1.4, max(r_smooth)*1.4]);
        ylim([min(h)-0.5, max(h)+1]);
        xlabel('Radius (\mum)'); ylabel('Height (\mum)');
        title('Cell Contour and Geometric Elements');
        grid on;
        legend({'Cell contour', 'Inscribed cone', 'Circumscribed sphere arc', 'Tip', 'Base', 'Sphere center'}, 'Location', 'best');
        hold off;
        
        % Right panel: volume comparison
        subplot(1, 2, 2);
        hold on;
        volumes = [V_cell, V_cone, V_sphere_cap];
        bar(volumes, 'FaceColor', [0.3 0.6 0.9]);
        set(gca, 'XTickLabel', {'Cell volume', 'Cone volume', 'Spherical cap volume'});
        ylabel('Volume (\mum^3)');
        title(sprintf('Taper T = %.4f', taper));
        text(1, max(volumes)*0.9, sprintf('T = %.4f', taper), ...
             'FontSize', 14, 'FontWeight', 'bold', 'HorizontalAlignment', 'center');
        text(0.5, 0.5, sprintf('Numerator = %.3f', V_sphere_cap - V_cell), ...
             'FontSize', 9, 'Color', 'b', 'HorizontalAlignment', 'center');
        text(2.5, 0.5, sprintf('Denominator = %.3f', V_sphere_cap - V_cone), ...
             'FontSize', 9, 'Color', 'r', 'HorizontalAlignment', 'center');
        grid on;
        hold off;
        
        fprintf('\n========== Detailed result for single curve ==========\n');
        fprintf('Tip: (r=%.3f, h=%.3f)\n', r_peak, h_peak);
        fprintf('Base: (r=%.3f, h=%.3f)\n', r_base, h_base);
        fprintf('Cell volume V_cell = %.3f\n', V_cell);
        fprintf('Cone volume V_cone = %.3f\n', V_cone);
        fprintf('Spherical cap volume V_sphere_cap = %.3f\n', V_sphere_cap);
        fprintf('Sphere center: (0, %.3f), radius R = %.3f\n', c, R);
        fprintf('Taper T = %.4f\n', taper);
    end
end